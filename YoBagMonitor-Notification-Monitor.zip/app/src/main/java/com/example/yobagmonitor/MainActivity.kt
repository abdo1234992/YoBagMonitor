package com.example.yobagmonitor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refreshRecords()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 18)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "YO Bag Monitor"
            textSize = 26f
            setTextColor(0xFF172033.toInt())
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "مراقبة إشعارات Wanasa فقط • بدون Root أو Accessibility"
            textSize = 14f
            setTextColor(0xFF5B6577.toInt())
            setPadding(0, 6, 0, 14)
        })

        statusText = TextView(this).apply {
            text = "راقب الإشعارات التي تصل من Wanasa. إذا كان نص الإشعار عامًا، فلن نستطيع معرفة تفاصيل الكيس منه."
            textSize = 14f
            setTextColor(0xFF344054.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(statusText)

        root.addView(Button(this).apply {
            text = "فتح إعدادات الوصول إلى الإشعارات"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "تحديث القائمة"
            setOnClickListener { refreshRecords() }
        })

        root.addView(TextView(this).apply {
            text = "إشعارات Wanasa المرصودة"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
            setPadding(0, 16, 0, 8)
        })

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "لا يقرأ التطبيق كلمات المرور أو الجلسات، ولا ينفّذ التقاطًا تلقائيًا."
            textSize = 11f
            setTextColor(0xFF7B8494.toInt())
            setPadding(0, 10, 0, 0)
        })
        setContentView(root)
        refreshRecords()
    }

    private fun refreshRecords() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val records = NotificationStore.all()
        if (records.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد إشعارات مرصودة بعد. فعّل الوصول للإشعارات، ثم انتظر إشعارًا جديدًا من Wanasa."
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(0xFF667085.toInt())
                setPadding(18, 28, 18, 28)
            })
            return
        }
        records.forEach { record ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = record.content
                textSize = 15f
                setTypeface(null, Typeface.BOLD)
                setTextColor(0xFF172033.toInt())
            })
            card.addView(TextView(this).apply {
                text = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    .format(Date(record.receivedAt))
                textSize = 12f
                setTextColor(0xFF667085.toInt())
                setPadding(0, 5, 0, 0)
            })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 8
            })
        }
    }
}
