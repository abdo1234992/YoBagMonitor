package com.example.yobagmonitor

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WanasaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Monitor only notifications from Wanasa; never reads app storage or login sessions.
        if (sbn.packageName != "com.weifan.yo") return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val content = listOf(title, text, bigText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" — ")
            .ifBlank { "وصل إشعار من Wanasa دون تفاصيل ظاهرة" }

        NotificationStore.add(
            NotificationRecord(
                packageName = sbn.packageName,
                content = content,
                receivedAt = System.currentTimeMillis()
            )
        )
    }
}

data class NotificationRecord(
    val packageName: String,
    val content: String,
    val receivedAt: Long
)

object NotificationStore {
    private val records = mutableListOf<NotificationRecord>()
    @Synchronized fun add(record: NotificationRecord) {
        records.add(0, record)
        while (records.size > 100) records.removeAt(records.lastIndex)
    }
    @Synchronized fun all(): List<NotificationRecord> = records.toList()
}
